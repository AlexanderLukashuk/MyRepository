#include <iostream>
#include <time.h>
using namespace std;

const int SIZE = 100;

void func(int array[])
{
    int sum1 = 0, sum2 = 0, count;
    for (int i = 0; i < SIZE; i++)
    {
        sum = 
    }
}

int main()
{
    srand(time(0));
    int array[SIZE];

    for (int i = 0; i < SIZE; i++)
    {
        array[i] = rand() % 100;
        cout << array[i] << " ";
    }
    cout << endl;

    return 0;
}
