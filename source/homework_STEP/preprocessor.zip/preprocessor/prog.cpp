#include "header.h"

Hello My Pes
Skobka
    POVTOR
    Skobka
        VIVOD << BALTIKA << FuckGoBack
        VIVOD << BEER << FuckGoBack
    Skobka2
    PeaceDeath
Skobka2
