#pragma once
#include <iostream>
using namespace std;

#define Hello int
#define My main
#define Pes ()
#define Skobka {
#define VIVOD cout
#define Skobka2 }
#define BALTIKA "Baltika 9"
#define FuckGoBack endl;
#define BEER "heavy beer"
#define PeaceDeath return 0;
#define POVTOR for(int i = 0; i < 10; i++)
